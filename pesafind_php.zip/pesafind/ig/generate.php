<?php
include_once 'database.php';
//include_once 'AfricasTalkingGateway.php';

//a class to handle database operations
class generate{ 
    private $db, $dbcon, $response, $queryStatus;
 
    public function __construct(){             
    $this->dbcon = new DBConnection();
    $this->db = $this->dbcon->connect();
    }   
     
   public function getColourItems($productnumber,$brandname){
     $stmt=$this->db->prepare("SELECT * FROM  `brands` WHERE productid=:productid and brandname=:brandname");
     $this->queryStatus = $stmt->execute(array(':productid' => $productnumber,':brandname'=>$brandname));
                if($this->queryStatus){
                    $resultSet = $stmt->fetchColumn();
                    /*$this->response = array();
                    $this->response["atms"] = array();
                    $this->response["atms"] = $resultSet;*/
                    //$this->response["status"] = "1";
                    $stmt=$this->db->prepare("SELECT * FROM  `items` WHERE  productid=:productid and brandid=:brandid");
                    $this->queryStatus = $stmt->execute(array(':productid' => $productnumber,':brandid'=>$resultSet));
                    if($this->queryStatus){
                      $resultSet = $stmt->fetchAll(PDO::FETCH_ASSOC);
                      $this->response = array();
                      $this->response["items"] = array();
                      $this->response["items"] = $resultSet;
                      $this->response["status"] = "1";
                }else{
                    $this->response["status"] = "0";
                }
                }else{
                    $this->response["status"] = "0";
                }
                
                return json_encode($this->response);
    }   
 
}
?>




