<?php
/**
 * Database configuration
 */
define('DB_USERNAME', 'eliteinn_tech');
define('DB_PASSWORD', 'Korir12Mwihaki');
define('DB_HOST', 'localhost');
define('DB_NAME', 'eliteinn_instantglam');

?>

