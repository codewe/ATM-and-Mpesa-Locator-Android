<?php
include_once 'generate.php';
$productnumber = $_GET['productNumber'];
$brandname = $_GET['brand'];
$generated = new generate();
echo $generated->getColourItems($productnumber,$brandname);

?>