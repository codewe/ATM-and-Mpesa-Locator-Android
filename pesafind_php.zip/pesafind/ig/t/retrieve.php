<?php
include_once 'generate.php';

if(isset($_GET['sid'])){
	switch($_GET['sid']){
		
		case 1:
                   
                   if(isset($_GET['productNumber']) and isset($_GET['brand'])){
                        $productnumber = $_GET['productNumber'];
                        $brandname = $_GET['brand'];
                        $generated = new generate();
                        echo $generated->getColourItems($productnumber,$brandname);
                      }else{
                        echo "Please provide product id";
                      }
                        break;
                case 2:                   
                   $selectedHos = new SelectedHospitals();
                   echo $selectedHos->getAllHospitals();
                
			break;
               
		default:
			echo 'UNKNOWN REQUEST';		
	}
}else{
	echo 'ERROR 100: Invalid request. Please provide service ID';
}

?>



