<?php
include_once 'config.php';
//a class to handle database connection
class DBConnection {
	
    private $db;

    function __construct() {   
    }

    /**
     * Establishing database connection
     * @return database connection handler
     */
    function connect() {		
       // Initialize DSN
        $dsn = 'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME;
        // Set PDO options
        $options = array(
            PDO::ATTR_PERSISTENT    => true,
            PDO::ATTR_ERRMODE       => PDO::ERRMODE_EXCEPTION
        );
        // Create a new PDO instance
        try{
            $this->db = new PDO($dsn, DB_USERNAME, DB_PASSWORD, $options);
			//echo 'Database connection successful';
        }
        // Catch any errors
        catch(PDOException $e){
            $this->error = $e->getMessage();
			echo $this->error;
        }
        // returning connection object
        return $this->db;
    }

}

?>
