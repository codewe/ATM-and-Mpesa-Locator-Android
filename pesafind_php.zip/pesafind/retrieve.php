<?php
include_once 'generate.php';
//$selectedHos = new SelecteHospitals();
//echo "hello";
if(isset($_GET['sid'])){
	switch($_GET['sid']){
		case 1:
                   $generated = new generate();
                   echo $generated->getMpesa();
			break; 
                case 2:
                   $generated = new generate();
                   echo $generated->getBanks();
			break;
                case 3:
                   $generated = new generate();
                   echo $generated->getATMs();
			break;
                case 4:
                     if(isset($_GET['bank_id'])){
                        $bank_id = $_GET['bank_id'];
                        $generated = new generate();
                        echo $generated->getBankATMs($bank_id);
                      }else{
                        echo "Please provide bank id";
                      }
                        break;
		default:
			echo 'UNKNOWN REQUEST';		
	}
}else{
	echo 'ERROR 100: Invalid request. Please provide service ID';
}

?>