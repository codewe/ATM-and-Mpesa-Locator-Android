<?php
include_once 'database.php';

//a class to handle database operations
class generate{ 
    private $db, $dbcon, $response, $queryStatus;
 
    public function __construct(){             
    $this->dbcon = new DBConnection();
    $this->db = $this->dbcon->connect();
    }   
    //selects and returns specific hospital details
     public function getMpesa(){
        $stmt = $this->db->prepare("SELECT * FROM mpesa");
        $this->queryStatus = $stmt->execute();
                if($this->queryStatus){
                    $resultSet = $stmt->fetchAll(PDO::FETCH_ASSOC);
                    $this->response = array();
                    $this->response["mpesa"] = array();
                    $this->response["mpesa"] = $resultSet;
                    $this->response["status"] = "1";
                }else{
                    $this->response["status"] = "0";
                }
                
                return json_encode($this->response);
     }
     public function getBanks(){
     $stmt=$this->db->prepare("SELECT * FROM banks");
     $this->queryStatus = $stmt->execute();
                if($this->queryStatus){
                    $resultSet = $stmt->fetchAll(PDO::FETCH_ASSOC);
                    $this->response = array();
                    $this->response["banks"] = array();
                    $this->response["banks"] = $resultSet;
                    $this->response["status"] = "1";
                }else{
                    $this->response["status"] = "0";
                }
                
                return json_encode($this->response);
    } 
    public function getATMs(){
     $stmt=$this->db->prepare("SELECT * FROM atms");
     $this->queryStatus = $stmt->execute();
                if($this->queryStatus){
                    $resultSet = $stmt->fetchAll(PDO::FETCH_ASSOC);
                    $this->response = array();
                    $this->response["atms"] = array();
                    $this->response["atms"] = $resultSet;
                    $this->response["status"] = "1";
                }else{
                    $this->response["status"] = "0";
                }
                
                return json_encode($this->response);
    } 
    public function getBankATMs($bank_id){
     $stmt=$this->db->prepare("SELECT * FROM atms WHERE bankid=:bankid");
     $this->queryStatus = $stmt->execute(array(':bankid' => $bank_id));
                if($this->queryStatus){
                    $resultSet = $stmt->fetchAll(PDO::FETCH_ASSOC);
                    $this->response = array();
                    $this->response["atms"] = array();
                    $this->response["atms"] = $resultSet;
                    $this->response["status"] = "1";
                }else{
                    $this->response["status"] = "0";
                }
                
                return json_encode($this->response);
    }  
}
?>